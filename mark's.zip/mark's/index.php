<?php
include 'configurations/config.php';

// get products from
$stmt = $pdo->query('SELECT products.product_id, products.name, products.description, products.price, products.seller_id, users.name AS seller_name FROM products JOIN users  ON products.seller_id = users.user_id');
$products = $stmt->fetchAll();

if (isset($_GET['message'])) {
    echo '<div class="alert alert-info" role="alert">' . htmlspecialchars($_GET['message']) . '</div>';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Listings</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        .nav-link{
            cursor: pointer;
        }
    </style>
</head>
<body>

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Shop System</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link active" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="modal" data-bs-target="#addProductModal">Add Product</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <h1>Products for Sale</h1>
    <div class="row">
        <?php foreach ($products as $product): ?>
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($product['name']); ?></h5>
                        <p class="card-text"><?php echo htmlspecialchars($product['description']); ?></p>
                        <p class="card-text"><strong>$<?php echo number_format($product['price'], 2); ?></strong></p>
                        <p class="card-text"><small class="text-muted">Seller: <?php echo htmlspecialchars($product['seller_name']); ?></small></p>
                        <!-- Edit Button -->
                        <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editProductModal" 
                            data-id="<?php echo $product['product_id']; ?>"
                            data-name="<?php echo $product['name']; ?>"
                            data-description="<?php echo $product['description']; ?>"
                            data-price="<?php echo $product['price']; ?>"
                            data-seller_id="<?php echo $product['seller_id']; ?>"
                        >Edit</button>
                        <!-- Delete Button -->
                        <a href="configurations/delete_product.php?product_id=<?php echo $product['product_id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this product?');">Delete</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>


<!-- Modal for Adding Product -->
<div class="modal fade" id="addProductModal" tabindex="-1" aria-labelledby="addProductModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addProductModalLabel">Add New Product</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="addProductForm">
            <div class="mb-3">
                <label for="addProductName" class="form-label">Product Name</label>
                <input type="text" class="form-control" id="addProductName" name="name" required>
            </div>
            <div class="mb-3">
                <label for="addProductDescription" class="form-label">Description</label>
                <textarea class="form-control" id="addProductDescription" name="description" required></textarea>
            </div>
            <div class="mb-3">
                <label for="addProductPrice" class="form-label">Price</label>
                <input type="number" class="form-control" id="addProductPrice" name="price" step="0.01" required>
            </div>
            <div class="mb-3">
                <label for="addProductSeller" class="form-label">Seller</label>
                <select class="form-control" id="addProductSeller" name="seller_id" required>
                    <?php
                    // Fetch sellers for the dropdown
                    $stmt = $pdo->query('SELECT user_id, name FROM users WHERE role = "seller"');
                    $sellers = $stmt->fetchAll();
                    foreach ($sellers as $seller) {
                        echo "<option value=\"{$seller['user_id']}\">{$seller['name']}</option>";
                    }
                    ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Add Product</button>
        </form>
      </div>
    </div>
  </div>
</div>


<!-- Modal for Editing Product -->
<div class="modal fade" id="editProductModal" tabindex="-1" aria-labelledby="editProductModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editProductModalLabel">Edit Product</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="editProductForm">
            <input type="hidden" id="editProductId" name="id">
            <div class="mb-3">
                <label for="editProductName" class="form-label">Product Name</label>
                <input type="text" class="form-control" id="editProductName" name="name" required>
            </div>
            <div class="mb-3">
                <label for="editProductDescription" class="form-label">Description</label>
                <textarea class="form-control" id="editProductDescription" name="description" required></textarea>
            </div>
            <div class="mb-3">
                <label for="editProductPrice" class="form-label">Price</label>
                <input type="number" class="form-control" id="editProductPrice" name="price" step="0.01" required>
            </div>
            <div class="mb-3">
                <label for="editProductSeller" class="form-label">Seller</label>
                <select class="form-control" id="editProductSeller" name="seller_id" required>
                    <?php
                    $stmt = $pdo->query('SELECT user_id, name FROM users WHERE role = "seller"');
                    $sellers = $stmt->fetchAll();
                    foreach ($sellers as $seller) {
                        echo "<option value=\"{$seller['id']}\">{$seller['name']}</option>";
                    }
                    ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Save Changes</button>
        </form>
      </div>
    </div>
  </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

<script>
    $('#editProductModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var name = button.data('name');
        var description = button.data('description');
        var price = button.data('price');
        var seller_id = button.data('seller_id');

        var modal = $(this);
        modal.find('#editProductId').val(id);
        modal.find('#editProductName').val(name);
        modal.find('#editProductDescription').val(description);
        modal.find('#editProductPrice').val(price);
        modal.find('#editProductSeller').val(seller_id);
    });

    //form edting product
    $('#editProductForm').submit(function(event) {
        event.preventDefault();

        var formData = $(this).serialize();

        $.ajax({
            url: 'configurations/update_product.php',
            type: 'POST',
            data: formData,
            success: function(response) {
                alert('Product updated successfully!');
                $('#editProductModal').modal('hide');
                location.reload();
            },
            error: function() {
                alert('Error updating the product');
            }
        });
    });

    //for adding a new product
    $('#addProductForm').submit(function(event) {
        event.preventDefault();

        var formData = $(this).serialize();

        $.ajax({
            url: 'configurations/add_product.php',
            type: 'POST',
            data: formData,
            success: function(response) {
                alert('Product added successfully!');
                $('#addProductModal').modal('hide');
                location.reload();
            },
            error: function() {
                alert('Error adding the product');
            }
        });
    });

</script>


</body>
</html>
