<?php
include 'configurations/config.php';

    session_start();
    if ($_SESSION['role'] != 'customer') {
        header('Location: login.php');
        exit;
    }

    $stmt = $pdo->query('SELECT products.product_id, products.name, products.description, products.price, products.seller_id, users.name AS seller_name FROM products JOIN users  ON products.seller_id = users.user_id');
    $products = $stmt->fetchAll();

    if (isset($_GET['message'])) {
        echo '<div class="alert alert-info" role="alert">' . htmlspecialchars($_GET['message']) . '</div>';
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        .nav-link {
            cursor: pointer;
        }
    </style>
</head>
<body>

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Shop System</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link active" href="customer.php">Products</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="cartButton" data-bs-toggle="modal" data-bs-target="#cartModal">Cart</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <h1>Products for Sale</h1>
    <div class="row">
        <?php foreach ($products as $product): ?>
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($product['name']); ?></h5>
                        <p class="card-text"><?php echo htmlspecialchars($product['description']); ?></p>
                        <p class="card-text"><strong>&#x20B1;<?php echo number_format($product['price'], 2); ?></strong></p>
                        <p class="card-text"><small class="text-muted">Seller: <?php echo htmlspecialchars($product['seller_name']); ?></small></p>
                        <a href="configurations/add_to_cart.php?product_id=<?php echo $product['product_id']; ?>" class="btn btn-success">Add to Cart</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Cart Modal -->
<div class="modal fade" id="cartModal" tabindex="-1" aria-labelledby="cartModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="cartModalLabel">Your Cart</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="cartContent">
                    <p>Loading your cart...</p>
                </div>
            </div>
            <div class="modal-footer">
                <a href="checkout.php" class="btn btn-primary">Proceed to Checkout</a>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Quantity Edit Modal -->
<div class="modal fade" id="quantityEditModal" tabindex="-1" aria-labelledby="quantityEditModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="quantityEditModalLabel">Edit Quantity</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editQuantityForm" method="POST">
                    <input type="hidden" id="editCartId" name="cart_id">
                    <div class="mb-3">
                        <label for="editQuantity" class="form-label">Quantity</label>
                        <input type="number" class="form-control" id="editQuantity" name="quantity" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Update Quantity</button>
                </form>
            </div>
        </div>
    </div>
</div>



<script>
    document.getElementById('cartButton').addEventListener('click', function () {
        $.ajax({
            url: 'configurations/cart_contents.php',
            method: 'GET',
            success: function (response) {
                $('#cartContent').html(response);
            },
            error: function () {
                $('#cartContent').html('<p class="text-danger">Failed to load cart contents.</p>');
            }
        });
    });

    $(document).ready(function () {
        $('.edit-quantity-btn').on('click', function () {
            var cartId = $(this).data('cart-id');
            var currentQuantity = $(this).data('quantity');

            $('#editCartId').val(cartId);
            $('#editQuantity').val(currentQuantity);

            $('#quantityEditModal').modal('show');
        });

        $('#editQuantityForm').on('submit', function (e) {
            e.preventDefault();

            var cartId = $('#editCartId').val();
            var quantity = $('#editQuantity').val();

            $.ajax({
                url: 'configurations/update_quantity.php',
                method: 'POST',
                data: { cart_id: cartId, quantity: quantity },
                success: function (response) {
                    $('#quantityEditModal').modal('hide');
                    
                    $('#cartModal').modal('hide');
                    $('#cartButton').trigger('click');
                },
                error: function () {
                    alert('Failed to update quantity');
                }
            });
        });
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
