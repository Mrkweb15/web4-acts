<?php
session_start();
include 'config.php';

if (isset($_SESSION['user_id']) && isset($_GET['cart_id'])) {
    $user_id = $_SESSION['user_id'];
    $cart_id = $_GET['cart_id'];
    
    // delete the item from the cart
    $stmt = $pdo->prepare('DELETE FROM cart WHERE cart_id = :cart_id AND user_id = :user_id');
    $stmt->execute(['cart_id' => $cart_id, 'user_id' => $user_id]);
    
    header('Location: ../customer.php?message=Item deleted');
    exit;
} else {
    echo 'Invalid request.';
}
?>
