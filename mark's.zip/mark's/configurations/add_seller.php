<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];

    $stmt = $pdo->prepare('INSERT INTO sellers (name, email) VALUES (?, ?)');
    $stmt->execute([$name, $email]);

    echo "Seller added successfully!";
}
?>
