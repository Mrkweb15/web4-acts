<?php
include 'config.php';

if (isset($_GET['product_id'])) {
    $productId = $_GET['product_id'];

    $stmt = $pdo->prepare("DELETE FROM products WHERE product_id = :product_id");
    $stmt->bindParam(':product_id', $productId, PDO::PARAM_INT);

    if ($stmt->execute()) {
        header("Location: ../index.php?message=Product deleted successfully");
        exit();
    } else {
        header("Location: ../index.php?message=Error deleting product");
        exit();
    }
} else {
    header("Location: ../index.php?message=Product ID missing");
    exit();
}
