<?php
session_start();
include 'config.php';

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    
    // get cart items
    $stmt = $pdo->prepare('SELECT cart.cart_id, products.name, products.price, cart.quantity 
                           FROM cart 
                           JOIN products ON cart.product_id = products.product_id 
                           WHERE cart.user_id = :user_id');
    $stmt->execute(['user_id' => $user_id]);
    $cart_items = $stmt->fetchAll();

    if ($cart_items) {
        echo '<ul class="list-group">';
        foreach ($cart_items as $item) {
            echo '<li class="list-group-item d-flex justify-content-between align-items-center">';
            echo htmlspecialchars($item['name']) . ' (x' . $item['quantity'] . ')';
            
            echo '<form action="configurations/update_quantity.php" method="POST" class="d-flex align-items-center">';
            echo '<input type="number" name="quantity" value="' . $item['quantity'] . '" min="1" class="form-control form-control-sm me-2" required>';
            echo '<input type="hidden" name="cart_id" value="' . $item['cart_id'] . '">';
            echo '<button type="submit" class="btn btn-primary btn-sm">Save</button>';
            echo '</form>';
            echo '<a href="configurations/delete_cart.php?cart_id=' . $item['cart_id'] . '" class="btn btn-danger btn-sm ms-2">Delete</a>';
            echo '</li>';
        }
        echo '</ul>';
    } else {
        echo '<p>Your cart is empty.</p>';
    }
} else {
    echo '<p class="text-danger">Please log in to view your cart.</p>';
}
?>
