<?php
session_start();
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_name = $_POST['product_name'];
    $product_description = $_POST['product_description'];
    $product_price = $_POST['product_price'];
    $user_id = $_SESSION['user_id'];

    $stmt = $pdo->prepare('INSERT INTO products (name, description, price, seller_id) VALUES (:product_name, :product_description, :product_price, :user_id)');
    $stmt->execute([
        'product_name' => $product_name,
        'product_description' => $product_description,
        'product_price' => $product_price,
        'user_id' => $user_id
    ]);

    echo '<p class="text-success">Product added successfully.</p>';
    header('Location: ../seller.php');
    exit;
}
?>
