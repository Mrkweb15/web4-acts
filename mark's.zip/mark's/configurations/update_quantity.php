<?php
session_start();
include 'config.php';

if (isset($_POST['cart_id'], $_POST['quantity'])) {
    $cart_id = $_POST['cart_id'];
    $quantity = $_POST['quantity'];
    
    if (is_numeric($quantity) && $quantity > 0) {
        $stmt = $pdo->prepare('UPDATE cart SET quantity = :quantity WHERE cart_id = :cart_id AND user_id = :user_id');
        $stmt->execute([
            'quantity' => $quantity,
            'cart_id' => $cart_id,
            'user_id' => $_SESSION['user_id']
        ]);
        
        
        header('Location: ../customer.php?message=Quantity Updated to cart successfully!');
        exit();
    } else {
        
        echo '<p class="text-danger">Invalid quantity.</p>';
    }
} else {
    
    echo '<p class="text-danger">Invalid request.</p>';
}
?>
