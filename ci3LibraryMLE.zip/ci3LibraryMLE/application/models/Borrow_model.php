<?php
    class Borrow_model extends CI_Model{
        
        public function __construct(){
            parent::__construct();
            $this->load->model('User_model');
            $this->load->library('session');
            $this->load->helper('url');
            $this->load->helper('form');
            $this->load->library('form_validation');
        }

        public function borrow_book($user_id, $book_id){
            $this->db->insert('borrowed_record', [
                'user_id' => $user_id,
                'book_id' => $book_id,
                'borrowed_date' => date('Y-m-d')
            ]);

            $this->db->where('id', $book_id);
            $this->db->update('books', ['status' => 'Borrowed']);
        }

        public function return_book($book_id){
            if(!$this->session->userdata('user_id')){
                $this->session->set_flashdata('message', '<div class="alert alert-danger">You must Log In to Return a Book.</div>');
                redirect('Auth/login');
                return;
            }

            $user_id = $this->session->userdata('user_id');

            $borrow_record = $this->db->query("
                SELECT * FROM borrowed_record WHERE user_id = $user_id AND book_id = $book_id AND return_date is NULL
            ")->row_array();

            if(!$borrow_record){
                $this->session->set_flashdata('message', '<div class="alert alert-danger"> You can only returb books you borrowed</div>');
                redirect('library');
                return;
            }
            $this->db->where('id', $borrow_record['id']);
            $this->db->update('Borrowed_record', ['return_date' => date('Y-m-d')]);

            $this->db->where('id', $book_id);
            $this->db->update('books', ['status' => 'Available']);

            $this->session->set_flashdata('message', '<div class="alert alert-success">Book has been Successfuly Returned.</div>');
            redirect('library');
        }
        
        public function get_transactions(){
            $query = $this->db->query("
                SELECT
                    b.Title,
                    b.published_year,
                    u.name,
                    br.borrowed_date,
                    br.return_date
                FROM borrowed_record br
                JOIN books b ON b.id = br.book_id
                JOIN users u ON u.id = br.user_id
                ORDER BY br.borrowed_date DESC
            ");
            return $query->result_array();
        }

    }
?>