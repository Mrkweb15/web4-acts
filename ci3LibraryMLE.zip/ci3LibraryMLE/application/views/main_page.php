<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main</title>
    <link rel="stylesheet" href="<?php echo base_url('res/dataTables.dataTables.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('res/bootstrap.min.css'); ?>">
</head>
<body>
    <div class="card">
        <div class="card-header">
            <h1 class="text-primary">Welcome to Library</h1>
        </div>
        <div class="card-body">
            <?php if($this->session->userdata('user_id')) { ?>
                <a href="<?= site_url('Library') ?>" class="btn btn-success">Go to Library</a>
                <a href="<?= site_url('Auth/logout') ?>" class="btn btn-warning">Logout</a>
            <?php } else { ?>
                <a href="<?= site_url('Auth/login') ?>" class="btn btn-warning">Login</a>
                <a href="<?= site_url('Auth/Register') ?>" class="btn btn-warning">Register</a>
            <?php } ?>
        </div>
    </div>
    
    <script src="<?php echo base_url('res/dataTables.min.js'); ?>"></script>
    <script src="<?php echo base_url('res/bootstrap.bundle.min.js'); ?>"></script>
    <script src="<?php echo base_url('res/jquery.min.js'); ?>"></script>
    <script src="<?php echo base_url('res/main.js'); ?>"></script>
</body>
</html>