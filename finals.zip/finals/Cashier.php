<?php
session_start();
include 'db.php';

// Initialize the selected products array in session if not already set
if (!isset($_SESSION['selected_products'])) {
    $_SESSION['selected_products'] = [];
}

// Retrieve products for sale
$products = [];
$result = $conn->query("SELECT * FROM products");
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
}

// Handle product selection and calculation
if (isset($_POST['add_product'])) {
    $product_id = $_POST['product_id'];
    $quantity_sold = $_POST['quantity'];
    $sale_price = $_POST['sale_price'];
    
    // Get product details
    $product_result = $conn->query("SELECT product_name, price FROM products WHERE product_id = '$product_id'");
    $product = $product_result->fetch_assoc();
    
    // Calculate total price for this product selection
    $item_total = $sale_price * $quantity_sold;

    // Add selected product to the session array
    $_SESSION['selected_products'][] = [
        'product_name' => $product['product_name'],
        'price' => $sale_price,
        'quantity' => $quantity_sold,
        'total' => $item_total,
        'product_id' => $product_id // Store product_id for sale processing
    ];
}

// Handle Sale Creation
if (isset($_POST['sell'])) {
    $total_price = 0;
    $error_messages = [];

    // Process each selected product and insert into the sales table
    foreach ($_SESSION['selected_products'] as $item) {
        $product_id = $item['product_id'];
        $quantity_sold = $item['quantity'];
        $sale_price = $item['price'];
        $total_sale = $item['total'];
        
        // Get current product quantity
        $product_result = $conn->query("SELECT quantity FROM products WHERE product_id = '$product_id'");
        $product = $product_result->fetch_assoc();
        $current_quantity = $product['quantity'];

        // Check if there's enough stock
        if ($current_quantity >= $quantity_sold) {
            // Deduct quantity from products table
            $new_quantity = $current_quantity - $quantity_sold;
            $conn->query("UPDATE products SET quantity = '$new_quantity' WHERE product_id = '$product_id'");

            // Insert sale into sales table
            $conn->query("INSERT INTO sales (product_id, quantity, total, sale_price) 
                        VALUES ('$product_id', '$quantity_sold', '$total_sale', '$sale_price')");

            $total_price += $total_sale;
        } else {
            // Collect error messages for each product with insufficient stock
            $error_messages[] = "Not enough stock for product: " . $item['product_name'];
        }
    }

    // If errors occurred, display them, otherwise clear session and finalize sale
    if (!empty($error_messages)) {
        $error_message = implode('<br>', $error_messages);
    } else {
        // Clear the session after the sale is processed
        unset($_SESSION['selected_products']);

        // Redirect or display success message
        header("Location: cashier.php?success=1&total_price=" . $total_price);
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cashier Sales</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Cashier Sales</h2>

        <!-- Success Message -->
        <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success">Sale completed successfully! Total: $<?= number_format($_GET['total_price'], 2) ?></div>
        <?php endif; ?>

        <!-- Error Message -->
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger"><?= $error_message ?></div>
        <?php endif; ?>

        <!-- Selected Products (Top Section) -->
        <div class="row mb-4">
            <div class="col-12">
                <h4>Selected Products</h4>
                <?php if (empty($_SESSION['selected_products'])): ?>
                    <p>No products selected yet.</p>
                <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Product Name</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $total_price = 0;
                            foreach ($_SESSION['selected_products'] as $item): 
                                $total_price += $item['total'];
                            ?>
                                <tr>
                                    <td><?= $item['product_name'] ?></td>
                                    <td><?= $item['quantity'] ?></td>
                                    <td><?= $item['price'] ?></td>
                                    <td><?= $item['total'] ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <h5>Total Price: $<?= number_format($total_price, 2) ?></h5>
                <?php endif; ?>
            </div>
        </div>

        <!-- Product Selection (Bottom Section) -->
        <form method="POST">
            <div class="row mb-4">
                <div class="col-md-4">
                    <label for="product" class="form-label">Select Product</label>
                    <select name="product_id" id="product" class="form-select">
                        <?php foreach ($products as $product): ?>
                            <option value="<?= $product['product_id'] ?>" data-price="<?= $product['price'] ?>"><?= $product['product_name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label for="quantity" class="form-label">Quantity</label>
                    <input type="number" name="quantity" id="quantity" class="form-control" min="1" required>
                </div>
                <div class="col-md-2">
                    <label for="sale_price" class="form-label">Sale Price</label>
                    <input type="number" name="sale_price" id="sale_price" class="form-control" readonly>
                </div>
                <div class="col-md-2">
                    <label for="add_product" class="form-label">&nbsp;</label>
                    <button type="submit" name="add_product" class="btn btn-primary form-control">Add Product</button>
                </div>
            </div>
        </form>

        <!-- Finalize Sale -->
        <form method="POST">
            <button type="submit" name="sell" class="btn btn-success">Finalize Sale</button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Update the sale price when a product is selected
        document.getElementById('product').addEventListener('change', function() {
            var selectedOption = this.options[this.selectedIndex];
            var price = selectedOption.getAttribute('data-price');
            document.getElementById('sale_price').value = price;
        });
    </script>
</body>
</html>
