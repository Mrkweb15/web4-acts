<?php
include 'db.php';

// Handle CRUD Operations

// Create Product
if (isset($_POST['create'])) {
    $product_name = $_POST['product_name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];
    $category_id = $_POST['category_id'];

    $sql = "INSERT INTO products (product_name, description, price, quantity, category_id) 
            VALUES ('$product_name', '$description', '$price', '$quantity', '$category_id')";
    if ($conn->query($sql) === TRUE) {
        echo "New product created successfully!";
        header("Location: index.php");
    } else {
        echo "Error: " . $conn->error;
    }
}

// Update Product
if (isset($_POST['update'])) {
    $product_id = $_POST['product_id'];
    $product_name = $_POST['product_name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];
    $category_id = $_POST['category_id'];

    $sql = "UPDATE products SET product_name='$product_name', description='$description', price='$price', quantity='$quantity', category_id='$category_id' WHERE product_id='$product_id'";
    if ($conn->query($sql) === TRUE) {
        echo "Product updated successfully!";
        header("Location: index.php");
    } else {
        echo "Error: " . $conn->error;
    }
}

// Delete Product
if (isset($_POST['delete'])) {
    $product_id = $_POST['product_id'];
    $sql = "DELETE FROM products WHERE product_id='$product_id'";
    if ($conn->query($sql) === TRUE) {
        echo "Product deleted successfully!";
        header("Location: index.php");
    } else {
        echo "Error: " . $conn->error;
    }
}

// Retrieve Products
$products = [];
$result = $conn->query("SELECT * FROM products");
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
}

// Fetch categories from the database
$categories = [];
$category_result = $conn->query("SELECT * FROM categories");
if ($category_result->num_rows > 0) {
    while ($row = $category_result->fetch_assoc()) {
        $categories[] = $row;
    }
}


// Fetch records from the 'sales' table
$sales_data = [];
$result = $conn->query("SELECT * FROM sales");
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $sales_data[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Inventory System</h2>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addProductModal">Add Product</button>
        <a class="btn btn-primary" href="Cashier.php">Sell Product</a>

        <!-- Product Table -->
        <table class="table mt-4" id="inventory">
            <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Description</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($products as $product): ?>
                    <tr>
                        <td><?= $product['product_name'] ?></td>
                        <td><?= $product['description'] ?></td>
                        <td><?= $product['price'] ?></td>
                        <td><?= $product['quantity'] ?></td>
                        <td>
                            <!-- Edit Button -->
                            <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editProductModal" 
                                    data-id="<?= $product['product_id'] ?>" data-name="<?= $product['product_name'] ?>" 
                                    data-description="<?= $product['description'] ?>" data-price="<?= $product['price'] ?>" 
                                    data-quantity="<?= $product['quantity'] ?>" data-category="<?= $product['category_id'] ?>">
                                Edit
                            </button>
                            <!-- Delete Button -->
                            <button class="btn btn-danger btn-sm deleteBtn" data-id="<?= $product['product_id'] ?>">Delete</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <hr>
    </div>


    <!--display sales-->
    <div class="container mt-5">
        <h2>Sales Records</h2>
        
        <?php if (empty($sales_data)): ?>
            <div class="alert alert-info">No sales records found.</div>
        <?php else: ?>
            <table id="salesTable" class="table table-bordered">
                <thead class="table-light">
                    <tr>
                        <th>Sale ID</th>
                        <th>Product ID</th>
                        <th>Sale Date</th>
                        <th>Quantity</th>
                        <th>Sale Price (₱)</th>
                        <th>Total (₱)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($sales_data as $sale): ?>
                        <tr>
                            <td><?= $sale['sale_id'] ?></td>
                            <td><?= $sale['product_id'] ?></td>
                            <td><?= $sale['sale_date'] ?></td>
                            <td><?= $sale['quantity'] ?></td>
                            <td>₱<?= number_format($sale['sale_price'], 2) ?></td>
                            <td>₱<?= number_format($sale['total'], 2) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <hr>
    <br>

    <!-- Add Product Modal -->
    <div class="modal" id="addProductModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Product</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label for="product_name" class="form-label">Product Name</label>
                            <input type="text" class="form-control" id="product_name" name="product_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="price" class="form-label">Price</label>
                            <input type="number" class="form-control" id="price" name="price" required>
                        </div>
                        <div class="mb-3">
                            <label for="quantity" class="form-label">Quantity</label>
                            <input type="number" class="form-control" id="quantity" name="quantity" required>
                        </div>
                        <div class="mb-3">
                            <label for="category_id" class="form-label">Category</label>
                            <select class="form-control" id="category_id" name="category_id" required>
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?= $category['category_id'] ?>"><?= $category['category_name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <button type="submit" name="create" class="btn btn-primary">Save Product</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Product Modal -->
    <div class="modal" id="editProductModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Product</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form method="POST">
                        <input type="hidden" id="edit_product_id" name="product_id">
                        <div class="mb-3">
                            <label for="edit_product_name" class="form-label">Product Name</label>
                            <input type="text" class="form-control" id="edit_product_name" name="product_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_description" class="form-label">Description</label>
                            <textarea class="form-control" id="edit_description" name="description" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="edit_price" class="form-label">Price</label>
                            <input type="number" class="form-control" id="edit_price" name="price" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_quantity" class="form-label">Quantity</label>
                            <input type="number" class="form-control" id="edit_quantity" name="quantity" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_category_id" class="form-label">Category</label>
                            <select class="form-control" id="edit_category_id" name="category_id" required>
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?= $category['category_id'] ?>"><?= $category['category_name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <button type="submit" name="update" class="btn btn-primary">Update Product</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function () {
            // Edit button logic
            $("#editProductModal").on('show.bs.modal', function (event) {
                var button = $(event.relatedTarget);
                var product_id = button.data('id');
                var product_name = button.data('name');
                var description = button.data('description');
                var price = button.data('price');
                var quantity = button.data('quantity');
                var category_id = button.data('category');

                $("#edit_product_id").val(product_id);
                $("#edit_product_name").val(product_name);
                $("#edit_description").val(description);
                $("#edit_price").val(price);
                $("#edit_quantity").val(quantity);
                $("#edit_category_id").val(category_id);
            });

            // Delete Product
            $(".deleteBtn").click(function () {
                var product_id = $(this).data('id');
                if (confirm("Are you sure you want to delete this product?")) {
                    $.ajax({
                        url: 'index.php',
                        type: 'POST',
                        data: { delete: true, product_id: product_id },
                        success: function (response) {
                            alert("Product deleted successfully!");
                            location.reload();
                        }
                    });
                }
            });

            $('#salesTable').DataTable({
                paging: true,
                searching: true,
                ordering: true,
                lengthMenu: [5, 10, 25, 50],
                language: {
                    search: "Search:",
                    lengthMenu: "Show _MENU_ entries",
                    info: "Showing _START_ to _END_ of _TOTAL_ records",
                    paginate: {
                        first: "First",
                        last: "Last",
                        next: "Next",
                        previous: "Previous"
                    }
                }
            });

            $('#inventory').DataTable({
                paging: true,
                searching: true,
                ordering: true,
                lengthMenu: [5, 10, 25, 50],
                language: {
                    search: "Search:",
                    lengthMenu: "Show _MENU_ entries",
                    info: "Showing _START_ to _END_ of _TOTAL_ records",
                    paginate: {
                        first: "First",
                        last: "Last",
                        next: "Next",
                        previous: "Previous"
                    }
                }
            });
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
