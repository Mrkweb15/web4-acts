<?php
include('config.php'); 

try {
    // Fetch staff data from database
    $sql = "SELECT staff.staff_id, staff.first_name, staff.last_name, staff.email, roles.role_name, departments.department_name
            FROM staff
            JOIN roles ON staff.role_id = roles.role_id
            JOIN departments ON staff.department_id = departments.department_id";
    $stmt = $pdo->query($sql);

    $staffData = [];

    if ($stmt->rowCount() > 0) {
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $staffData[] = $row;  // Store each row in the array
        }
    } else {
        echo "<tr><td colspan='7'>No staff found</td></tr>";
    }

    // Fetch attendance data from the database
    $sql = "SELECT attendance.attendance_id, attendance.staff_id, staff.first_name, staff.last_name, attendance.attendance_date, attendance.status
            FROM attendance
            JOIN staff ON attendance.staff_id = staff.staff_id
            ORDER BY attendance.attendance_date DESC";
    $stmt = $pdo->query($sql);

    $attendanceData = [];

    if ($stmt->rowCount() > 0) {
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $attendanceData[] = $row;  // Store each attendance record in the array
        }
    } else {
        echo "<tr><td colspan='6'>No attendance records found</td></tr>";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="container mt-5">
        <h2>Staff Management</h2>

        <!-- Add Staff Button -->
        <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addStaffModal">Add New Staff</button>

        <!-- Staff Table -->
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Department</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($staffData as $row): ?>
                    <tr>
                        <td><?php echo $row['staff_id']; ?></td>
                        <td><?php echo $row['first_name']; ?></td>
                        <td><?php echo $row['last_name']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['role_name']; ?></td>
                        <td><?php echo $row['department_name']; ?></td>
                        <td>
                            <button class='btn btn-warning btn-sm' data-bs-toggle='modal' data-bs-target='#editStaffModal'
                                data-id='<?php echo $row['staff_id']; ?>'
                                data-first-name='<?php echo $row['first_name']; ?>'
                                data-last-name='<?php echo $row['last_name']; ?>'
                                data-email='<?php echo $row['email']; ?>'
                                data-role='<?php echo isset($row['role_id']) ? $row['role_id'] : ''; ?>'
                                data-department='<?php echo isset($row['department_id']) ? $row['department_id'] : ''; ?>'>
                                Edit
                            </button>
                            <button class='btn btn-danger btn-sm delete-btn' data-id='<?php echo $row['staff_id']; ?>'>Delete</button>

                            <!-- In and Out buttons -->
                            <button class='btn btn-success btn-sm attendance-btn' data-id='<?php echo $row['staff_id']; ?>' data-status='In'>In</button>
                            <button class='btn btn-danger btn-sm attendance-btn' data-id='<?php echo $row['staff_id']; ?>' data-status='Out'>Out</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>

        </table>
    </div>
    <!-- Attendance Table -->
<div class="container mt-5">
    <h2>Attendance Management</h2>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Staff Name</th>
                <th>Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($attendanceData as $row): ?>
                <tr>
                    <td><?php echo $row['attendance_id']; ?></td>
                    <td><?php echo $row['first_name'] . ' ' . $row['last_name']; ?></td>
                    <td><?php echo $row['attendance_date']; ?></td>
                    <td><?php echo ucfirst($row['status']); ?></td>
                    <td>
                        <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editAttendanceModal"
                            data-id="<?php echo $row['attendance_id']; ?>"
                            data-status="<?php echo $row['status']; ?>"
                            data-staff-id="<?php echo $row['staff_id']; ?>"
                            data-date="<?php echo $row['attendance_date']; ?>">
                            Edit
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>

        </tbody>
    </table>
</div>

<!-- Edit Attendance Modal -->
<div class="modal fade" id="editAttendanceModal" tabindex="-1" aria-labelledby="editAttendanceModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editAttendanceModalLabel">Edit Attendance</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editAttendanceForm">
                    <input type="hidden" id="attendanceId">
                    <div class="mb-3">
                        <label for="editStatus" class="form-label">Attendance Status</label>
                        <select id="editStatus" class="form-control">
                            <option value="present">Present</option>
                            <option value="absent">Absent</option>
                            <option value="leave">Leave</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </form>
            </div>
        </div>
    </div>
</div>

    <!-- Add Staff Modal -->
    <div class="modal fade" id="addStaffModal" tabindex="-1" aria-labelledby="addStaffModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addStaffModalLabel">Add New Staff</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="addStaffForm">
                        <div class="mb-3">
                            <label for="firstName" class="form-label">First Name</label>
                            <input type="text" class="form-control" id="firstName" required>
                        </div>
                        <div class="mb-3">
                            <label for="lastName" class="form-label">Last Name</label>
                            <input type="text" class="form-control" id="lastName" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="role" class="form-label">Role</label>
                            <select id="role" class="form-control">
                                <option value="1">Manager</option>
                                <option value="2">Developer</option>
                                <option value="3">HR</option>
                                <option value="4">Accountant</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="department" class="form-label">Department</label>
                            <select id="department" class="form-control">
                                <option value="1">HR</option>
                                <option value="2">Engineering</option>
                                <option value="3">Finance</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Save Staff</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Staff Modal -->
    <div class="modal fade" id="editStaffModal" tabindex="-1" aria-labelledby="editStaffModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editStaffModalLabel">Edit Staff</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editStaffForm">
                        <input type="hidden" id="editStaffId">
                        <div class="mb-3">
                            <label for="editFirstName" class="form-label">First Name</label>
                            <input type="text" class="form-control" id="editFirstName" required>
                        </div>
                        <div class="mb-3">
                            <label for="editLastName" class="form-label">Last Name</label>
                            <input type="text" class="form-control" id="editLastName" required>
                        </div>
                        <div class="mb-3">
                            <label for="editEmail" class="form-label">Email</label>
                            <input type="email" class="form-control" id="editEmail" required>
                        </div>
                        <div class="mb-3">
                            <label for="editRole" class="form-label">Role</label>
                            <select id="editRole" class="form-control">
                                <option value="1">Manager</option>
                                <option value="2">Developer</option>
                                <option value="3">HR</option>
                                <option value="4">Accountant</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="editDepartment" class="form-label">Department</label>
                            <select id="editDepartment" class="form-control">
                                <option value="1">HR</option>
                                <option value="2">Engineering</option>
                                <option value="3">Finance</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            // Edit Button
            $('#editStaffModal').on('show.bs.modal', function(event) {
                var button = $(event.relatedTarget);
                var staffId = button.data('id');
                var firstName = button.data('first-name');
                var lastName = button.data('last-name');
                var email = button.data('email');
                var role = button.data('role');
                var department = button.data('department');
                
                $('#editStaffId').val(staffId);
                $('#editFirstName').val(firstName);
                $('#editLastName').val(lastName);
                $('#editEmail').val(email);
                $('#editRole').val(role);
                $('#editDepartment').val(department);
            });

            // Add Staff
            $('#addStaffForm').submit(function(e) {
                e.preventDefault();
                var firstName = $('#firstName').val();
                var lastName = $('#lastName').val();
                var email = $('#email').val();
                var role = $('#role').val();
                var department = $('#department').val();
                
                $.ajax({
                    url: 'staff.php',
                    type: 'POST',
                    data: {
                        action: 'add',
                        first_name: firstName,
                        last_name: lastName,
                        email: email,
                        role_id: role,
                        department_id: department
                    },
                    success: function(response) {
                        location.reload();
                    }
                });
            });


            // Edit Staff
            $('#editStaffForm').submit(function(e) {
                e.preventDefault();
                var staffId = $('#editStaffId').val();
                var firstName = $('#editFirstName').val();
                var lastName = $('#editLastName').val();
                var email = $('#editEmail').val();
                var role = $('#editRole').val();
                var department = $('#editDepartment').val();

                $.ajax({
                    url: 'staff.php',
                    type: 'POST',
                    data: {
                        action: 'edit',
                        staff_id: staffId,
                        first_name: firstName,
                        last_name: lastName,
                        email: email,
                        role_id: role,
                        department_id: department
                    },
                    success: function(response) {
                        location.reload();
                    }
                });
            });

            // Delete Button
            $('.delete-btn').click(function() {
                var staffId = $(this).data('id');

                if (confirm('Are you sure you want to delete this staff?')) {
                    $.ajax({
                        url: 'staff.php',
                        type: 'POST',
                        data: {
                            action: 'delete',
                            staff_id: staffId
                        },
                        success: function(response) {
                            location.reload();
                        }
                    });
                }
            });

            // Edit Button
            $('#editAttendanceModal').on('show.bs.modal', function(event) {
                var button = $(event.relatedTarget);
                var attendanceId = button.data('id');
                var status = button.data('status');
                var staffId = button.data('staff-id');
                var date = button.data('date');

                $('#attendanceId').val(attendanceId);
                $('#editStatus').val(status);
            });

            // Edit Attendance Form Submission
            $('#editAttendanceForm').submit(function(e) {
                e.preventDefault();
                var attendanceId = $('#attendanceId').val();
                var status = $('#editStatus').val();

                $.ajax({
                    url: 'attendance.php',
                    type: 'POST',
                    data: {
                        action: 'edit',
                        attendance_id: attendanceId,
                        status: status
                    },
                    success: function(response) {
                        location.reload();
                    }
                });
            });

            // for "In" and "Out" buttons
            $('.attendance-btn').on('click', function() {
                var staffId = $(this).data('id'); 
                var status = $(this).data('status');
                var action = (status === 'In') ? 'login' : 'logout';
                var time = new Date().toLocaleTimeString();

                $.ajax({
                    url: 'update_attendance.php',
                    type: 'POST',
                    data: {
                        staff_id: staffId,
                        time: time,
                        action: action
                    },
                    success: function(response) {
                        alert(response);
                        location.reload(); 
                    },
                    error: function(xhr, status, error) {
                        alert("An error occurred: " + error);
                    }
                });
            });

        });
    </script>
</body>
</html>
