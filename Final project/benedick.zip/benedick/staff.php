<?php
include('config.php');

// Handle Add Staff
if (isset($_POST['action']) && $_POST['action'] == 'add') {
    $firstName = $_POST['first_name'];
    $lastName = $_POST['last_name'];
    $email = $_POST['email'];
    $roleId = $_POST['role_id'];
    $departmentId = $_POST['department_id'];

    try {
        // Prepare and execute insert query using PDO
        $sql = "INSERT INTO staff (first_name, last_name, email, role_id, department_id) 
                VALUES (:first_name, :last_name, :email, :role_id, :department_id)";
        
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':first_name', $firstName);
        $stmt->bindParam(':last_name', $lastName);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':role_id', $roleId);
        $stmt->bindParam(':department_id', $departmentId);
        
        $stmt->execute();
        echo "Staff added successfully.";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}

// Handle Edit Staff
if (isset($_POST['action']) && $_POST['action'] == 'edit') {
    $staffId = $_POST['staff_id'];  
    $firstName = $_POST['first_name'];
    $lastName = $_POST['last_name'];
    $email = $_POST['email'];
    $roleId = $_POST['role_id'];
    $departmentId = $_POST['department_id'];

    try {
        // Prepare and execute update query using PDO
        $sql = "UPDATE staff SET first_name=:first_name, last_name=:last_name, email=:email, 
                role_id=:role_id, department_id=:department_id WHERE staff_id=:staff_id";
        
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':staff_id', $staffId);
        $stmt->bindParam(':first_name', $firstName);
        $stmt->bindParam(':last_name', $lastName);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':role_id', $roleId);
        $stmt->bindParam(':department_id', $departmentId);
        
        $stmt->execute();
        echo "Staff updated successfully.";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}

// Handle Delete Staff
if (isset($_POST['action']) && $_POST['action'] == 'delete') {
    $staffId = $_POST['staff_id'];

    try {
        // Prepare and execute delete query using PDO
        $sql = "DELETE FROM staff WHERE staff_id=:staff_id";
        
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':staff_id', $staffId);
        
        $stmt->execute();
        echo "Staff deleted successfully.";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
