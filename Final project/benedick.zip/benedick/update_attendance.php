<?php
include('config.php'); 

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['staff_id']) && isset($_POST['time']) && isset($_POST['action'])) {
    $staff_id = $_POST['staff_id'];
    $time = $_POST['time'];  // Time of the action (login or logout)
    $action = $_POST['action'];  // 'login' or 'logout'

    // Convert time to the appropriate format
    $attendance_time = strtotime($time); // Time passed from the form (e.g., "08:00 AM")

    try {
        // Check if the user already has an attendance record for today
        $sql = "SELECT * FROM attendance WHERE staff_id = ? AND attendance_date = CURDATE()";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$staff_id]);

        // If the user is logging in
        if ($action == 'login') {
            if ($attendance_time > strtotime('07:00:00')) {
                // If login time is after 7 AM, prevent login
                echo "Login is not allowed after 7 AM.";
                exit();
            }

            if ($attendance_time >= strtotime('05:00:00') && $attendance_time <= strtotime('06:00:00')) {
                $status = 'Working'; // Login between 5:00 AM to 6:00 AM
            } elseif ($attendance_time > strtotime('06:00:00') && $attendance_time <= strtotime('07:00:00')) {
                $status = 'Late'; // Login between 6:00 AM to 7:00 AM
            } else {
                $status = 'Absent'; // Login after 7:00 AM
            }

            if ($stmt->rowCount() > 0) {
                // Update existing attendance record for today
                $sql = "UPDATE attendance SET status = ? WHERE staff_id = ? AND attendance_date = CURDATE()";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$status, $staff_id]);
            } else {
                // Insert a new attendance record for today
                $sql = "INSERT INTO attendance (staff_id, attendance_date, status) VALUES (?, CURDATE(), ?)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$staff_id, $status]);
            }

            echo "Attendance updated successfully!";

        } elseif ($action == 'logout') {
            if ($attendance_time > strtotime('20:00:00')) {
                // If logout time is after 8 PM, prevent logout
                echo "Logout is not allowed after 8 PM.";
                exit();
            }

            if ($stmt->rowCount() == 0) {
                // If the user has not logged in yet today, they can't log out
                echo "You must log in first before logging out.";
                exit();
            }

            // If logout is before 5 AM, the status is considered 'Absent'
            if ($attendance_time >= strtotime('05:00:00') && $attendance_time <= strtotime('06:00:00')) {
                $status = 'Present'; // Logout between 5:00 AM to 6:00 AM
            } else {
                $status = 'Absent'; // Logout after 6:00 AM
            }

            // Update attendance status for logout
            $sql = "UPDATE attendance SET status = ? WHERE staff_id = ? AND attendance_date = CURDATE()";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$status, $staff_id]);

            echo "Attendance updated successfully!";
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
